﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by NSudoLauncherResources.rc
#define IDI_NSUDO_LAUNCHER              2000
#define IDR_STRING_TRANSLATIONS         2001
#define IDR_STRING_COMMAND_LINE_HELP    2002
#define IDR_STRING_LINKS                2003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
