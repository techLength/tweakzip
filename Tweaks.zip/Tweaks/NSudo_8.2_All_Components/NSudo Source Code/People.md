﻿# NSudo - 相关人士 Relevant People

## 提示 Notice

- 本列表按字母顺序排列。
- This list sort in alphabetical order.

## 创立者 Creator

- Mouri_Naruto ([https://github.com/MouriNaruto](https://github.com/MouriNaruto))

## 原型作者 Prototype author

- raymai97 ([https://github.com/Raymai97](https://github.com/Raymai97))

## 贡献者 Contributors

- 20011010wo ([https://github.com/yangrq](https://github.com/yangrq))
- Bill ([https://github.com/bianyifan](https://github.com/bianyifan))
- Eugene Wang J.y ([https://github.com/ewjy](https://github.com/ewjy))
- Force.Charlie-I ([https://github.com/fcharlie](https://github.com/fcharlie))
- garf02 ([https://github.com/garf02](https://github.com/garf02))
- laosb ([https://github.com/laosb](https://github.com/laosb))
- 罗宇凡 Luo Yufan ([https://github.com/njlyf2011](https://github.com/njlyf2011))
- Margen67 ([https://github.com/Margen67](https://github.com/Margen67))
- May_magic ([https://github.com/873578156](https://github.com/873578156))
- Microsoft_Mars
- Miguel Obando ([https://github.com/obando777](https://github.com/obando777))
- mingkuang ([https://github.com/mingkuang-Chuyu](https://github.com/mingkuang-Chuyu))
- myfreeer ([https://github.com/myfreeer](https://github.com/myfreeer))
- 青春永不落幕 ([https://github.com/qcyblm](https://github.com/qcyblm))
- Steve ([https://github.com/uDEV2019](https://github.com/uDEV2019))
- Thomas Dubreuil ([https://github.com/Thdub](https://github.com/Thdub))

## 赞助者 Sponsors

- 安磊磊
- boyangpangzi
- cjy\_\_05
- dfdc5
- mhxkx
- NotePad
- tangmigoId
- wondersnefu
- xy137425740
- 龍魂
- 月光光

## 反馈者 Advicers

- 4071E95D-A09B-4AA3-8008
- abbodi1406
- AeonX
- Domagoj Smolčić
- hydra79545
- imadlatch
- jgtoy
- kCaRhC 卡壳
- Lenny
- NotePad
- sebus
- testtest322
- th1r5bvn23
- 老九
- 龍魂
- 芈员外
- xspeed1989 (成都领沃科技-常炯)([https://github.com/xspeed1989](https://github.com/xspeed1989))
- 鸢一雨音 ([https://github.com/TobiichiAmane](https://github.com/TobiichiAmane))
- さくら

## 特别感谢 Special thanks

- 高坂穂乃果 (因为知晓了她的事迹, 使我没有放弃对 NSudo 的开发)
